#!/bin/bash

# Emotional Support AI - Deployment Script for Linode

set -e

echo "🚀 Starting deployment of Emotional Support AI..."

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Pull latest changes
echo "📦 Pulling latest code..."
git pull origin main

# Build and start Docker containers
echo "🐳 Building Docker images..."
docker-compose build

echo "🚢 Starting services..."
docker-compose up -d

# Wait for services to be ready
echo "⏳ Waiting for services to be ready..."
sleep 10

# Run database migrations
echo "🗄️ Running database migrations..."
docker-compose exec backend python -c "from app import create_app; from app.models import db; db.create_all()"

# Check health
echo "🏥 Checking service health..."
curl -f http://localhost:5000/api/health || echo "⚠️ Health check failed"

# Setup SSL with Certbot (first time only)
if [ ! -f ./ssl/cert.pem ]; then
    echo "🔒 Setting up SSL certificate..."
    docker-compose stop nginx
    certbot certonly --standalone -d your-domain.com --email your-email@example.com --agree-tos --non-interactive
    cp /etc/letsencrypt/live/your-domain.com/fullchain.pem ./ssl/cert.pem
    cp /etc/letsencrypt/live/your-domain.com/privkey.pem ./ssl/key.pem
    docker-compose start nginx
fi

# Setup auto-renewal for SSL
echo "🔄 Setting up SSL auto-renewal..."
(crontab -l 2>/dev/null; echo "0 0 1 * * docker-compose exec nginx certbot renew --quiet") | crontab -

echo "✅ Deployment complete!"
echo "🌐 Application is running at https://your-domain.com"
echo "📊 Monitor logs with: docker-compose logs -f"